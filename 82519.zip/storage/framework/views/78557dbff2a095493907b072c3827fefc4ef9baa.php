

<?php $__env->startSection('content'); ?>
<div class="container">
      <div class="row-justify-content-center">
          <div class="col-md-8">
              <div class="card">
                  <div class="card-header">
                       <h3 class="text-center">Add an new student</h3>
                  </div>
                  <div class="card-body">
                  <table class="table">
                   <thead>
                   <tr>
                   <th>Student Number</th>
                   <th>Student Name</th>
                   <th>Date of Payment</th>
                   <th>Amount Paid</th>
                   </tr>
                   </thead> 
                   <tbody>
                   <?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                   <td><?php echo e($fee->student_number); ?></td>
                   <td><?php echo e($fee->students->full_name); ?></td>
                   <td><?php echo e($fee->date_of_payment); ?></td>
                   <td><?php echo e($fee->amount); ?></td>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                  </table>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('miseda.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\82519\resources\views/miseda/feePayments.blade.php ENDPATH**/ ?>